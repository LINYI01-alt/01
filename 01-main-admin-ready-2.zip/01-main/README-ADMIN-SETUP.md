# 邻伊网站：投稿表单与管理后台（接入准备版）

## 本次加入
- `admin.html`：不在网站导航中展示的管理入口，地址为 `/admin.html`
- `js/admin.js`：Supabase Auth 登录、投稿列表、筛选、通过/退回/删除
- `pages/fenxiang.html`：把原来的微信投稿提示改成网站投稿表单
- `js/submission.js`：向 `public.submissions` 插入待审核投稿
- `js/supabase-config.js`：Supabase 项目 URL 与 publishable key 配置
- `css/style.css`：投稿表单样式

## 安全说明
1. 前端只使用 Supabase publishable key（或旧 anon key），绝不使用 `service_role` / `sb_secret`。
2. 管理后台地址隐藏不构成安全措施；真实权限必须由 Supabase Auth + RLS 决定。
3. 管理员页面的读取、更新和删除操作依赖当前数据库的 RLS 策略。若登录后无法审核，先检查当前登录用户是否为数据库策略授权的管理员身份。
4. 目前数据库的 `read approved` 策略允许匿名用户读取已批准的 `share` / `story` 行。因为 `submissions` 表还有 `contact` 联系方式列，行级安全并不会自动隐藏该列。**正式开放公开读取前，应先把联系方式拆到管理员专用表或另行实施列级保护。** 本次投稿页只执行 INSERT，不在公开页面读取投稿记录。
5. 不要在仓库、HTML 或 JavaScript 中放入密码、Personal Access Token、service_role 或 secret key。

## 部署前需要完成的验证
- 在 Supabase Auth 中确认管理员账号可用。
- 用管理员账号登录 `/admin.html`，确认能读取待审核投稿。
- 分别测试通过、退回、删除；删除不可撤销。
- 用未登录浏览器提交一条测试投稿，确认新增记录状态为 `pending`。
- 检查网站部署平台是否将根目录 `01-main/` 作为发布目录。

## 目前发现的站点信息不一致
- `footer.html` 中仍残留旧的 GitHub Pages 地址 `yafeihe759-alt.github.io/01/pages/kepu.html`
请确认最终正式域名后，再统一 canonical、站内链接与部署域名。`footer.html` 当前看起来不是被页面引用的公共页，但建议清理旧链接。
